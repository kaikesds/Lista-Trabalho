package Main;


import ListaDuplamenteEncadeada.ListaDuplamenteEncadeada;
import com.mycompany.lista.Cliente;
import javax.swing.*;

public class CadastroCliente {
    private static ListaDuplamenteEncadeada listaClientes = 
                                                new ListaDuplamenteEncadeada();

    public static void main(String[] args) {
        while (true) {
            String[] options = {"Adicionar Cliente", "Excluir Cliente", 
                "Alterar Cliente", "Recuperar Cliente",
                "Exibir Todos os Clientes", "Sair"};
            int opcao = JOptionPane.showOptionDialog
                (null, "Escolha uma opção",
                                    "Menu",
                    JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE,
                                                null, options, options[0]);

            switch (opcao) {
                case 0:
                    adicionarCliente();
                    break;
                case 1:
                    excluirCliente();
                    break;
                case 2:
                    alterarCliente();
                    break;
                case 3:
                    recuperarCliente();
                    break;
                case 4:
                    exibirTodosClientes();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null,
                                                            "Saindo");
                    return;
                default:
                    JOptionPane.showMessageDialog(null,
                                      "Opção inválida. Tente novamente.");
                    break;
            }
        }
    }

    private static void adicionarCliente() {
        try {
            int codigo = Integer.parseInt(JOptionPane.showInputDialog
                                        ("Informe o código do cliente:"));
            String nome = JOptionPane.showInputDialog
                                           ("Informe o nome do cliente:");
            String dataNascimento = JOptionPane.showInputDialog
                ("Informe a data de nascimento do cliente (DD/MM/AAAA):");
            String telefone = JOptionPane.showInputDialog
                                       ("Informe o telefone do cliente:");

            // Validações simples
            if (nome == null || nome.isEmpty()) {
                throw new IllegalArgumentException("Nome inválido.");
            }
            if (!dataNascimento.matches("\\d{2}/\\d{2}/\\d{4}")) {
                throw new IllegalArgumentException
                                             ("Data de nascimento inválida.");
            }
            if (!telefone.matches("\\d{10,11}")) {
                throw new IllegalArgumentException("Telefone inválido.");
            }

            Cliente cliente = new Cliente
                                       (codigo, nome, dataNascimento, telefone);
            listaClientes.adicionarCliente(cliente);
            JOptionPane.showMessageDialog
                    (null, "Cliente adicionado com sucesso!");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog
                        (null,
                          "Código inválido  Deve ser um número inteiro.");
        } catch (IllegalArgumentException e) {
          JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    private static void excluirCliente() {
        try {
            int codigo = Integer.parseInt(JOptionPane.showInputDialog
                        ("Informe o código do cliente a ser excluido:"));
            Cliente clienteExcluido = listaClientes.excluirCliente(codigo);
            if (clienteExcluido != null) {
                JOptionPane.showMessageDialog(null,
                        "Cliente excluido com sucesso\n" + clienteExcluido);
            } else {
                JOptionPane.showMessageDialog(null,
                     "Nenhum cliente encontrado com o codigo informado.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                          "Codigo invalido. Deve ser um numero inteiro.");
        }
    }

    private static void alterarCliente() {
        try {
            int codigo = Integer.parseInt(JOptionPane.showInputDialog
                         ("Informe o codigo do cliente a ser alterado:"));
            Cliente cliente = listaClientes.recuperarCliente(codigo);
            if (cliente != null) {
                String nome = JOptionPane.showInputDialog
                                ("Informe o novo nome do cliente (atual: " 
                                                    + cliente.getNome() + "):");
                String dataNascimento = JOptionPane.showInputDialog
                        ("Informe a nova data de nascimento do cliente (atual: "
                                          + cliente.getDataNascimento() + "):");
                String telefone = JOptionPane.showInputDialog
                                  ("Informe o novo telefone do cliente (atual: "
                                               + cliente.getTelefone() + "):");

                // Validações simples
                if (nome == null || nome.isEmpty()) {
                    throw new IllegalArgumentException("Nome invalido.");
                }
                if (!dataNascimento.matches("\\d{2}/\\d{2}/\\d{4}")) {
                    throw new IllegalArgumentException
                                             ("Data de nascimento invalida.");
                }
                if (!telefone.matches("\\d{10,11}")) {
                    throw new IllegalArgumentException("Telefone invalido.");
                }

                cliente.setNome(nome);
                cliente.setDataNascimento(dataNascimento);
                cliente.setTelefone(telefone);

                listaClientes.alterarCliente(codigo, 
                        nome, dataNascimento,
                                                            telefone);
                JOptionPane.showMessageDialog(null, 
                                         "Cliente alterado com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, 
                     "Nenhum cliente encontrado com o código informado.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, 
                          "Código inválido. Deve ser um número inteiro.");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog
                                       (null, e.getMessage());
        }
    }

    private static void recuperarCliente() {
        try {
            int codigo = Integer.parseInt(JOptionPane.showInputDialog
                                        ("Informe o código do cliente:"));
            Cliente cliente = listaClientes.recuperarCliente(codigo);
            if (cliente != null) {
                JOptionPane.showMessageDialog(null,
                                               "Dados do Cliente:\n" + cliente);
            } else {
                JOptionPane.showMessageDialog(null, 
                     "Nenhum cliente encontrado com o código informado.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,
                          "Codigo invalido. Deve ser um número inteiro.");
        }
    }

    private static void exibirTodosClientes() {
        String todosClientes = listaClientes.exibirTodosClientes();
        JOptionPane.showMessageDialog(null, "Todos os Clientes:\n"
                                                               + todosClientes);
    }
    

}

            
    

        
